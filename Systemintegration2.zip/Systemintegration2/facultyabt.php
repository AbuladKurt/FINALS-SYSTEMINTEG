<?php 
    include 'config.php';
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial scale=1.0">
        <title>Homepage</title>
        <link rel="stylesheet" href="css/faculty.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,700;1,200;1,400&display=swap" rel="stylesheet">
    </head>
    <style>
         .Elib p{
            color: #fff;
            text-align: center;
            margin-top: 200px;
            font-size: large;
        }

         .nameleft a {

            text-decoration: none;
            color: white;

         }
    </style>
    <body>
    
        <section class="header">
        <nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="facultyhome.php">Home</a></li>
                        <li><a href="facmy.php">My Courses</a></li>
                        <li><a href="facultymnv.php">Mission and Vision</a></li>
                        <li><a href="facultyabt.php">About</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            
            <section class="Elib">
            <p>This LMS provides certain books that you may read on this website simply<br>by searching for it. This guide you in developing interests such as more learning.</p>
                </section>



            <section class="cta1">
                <h1>Enroll For Our Various Online Courses<br>Anywhere From Marilao, Bulacan</h1>
                <a href="https://www.facebook.com/TMCSOfficialpage" class="hero-btn">CONTACT US</a>    
            </section>
        </section>

    </body>
</html>