<?php 

    include 'config.php';
    session_start();
    include 'middlewares/admin-guard.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/design.css">
    <link rel="stylesheet" href="css/admin.css">
    <title>Add User</title>
</head>
<body>
<nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="admhome.php">Home</a></li>
                        <li><a href="admmycourse.php">My Courses</a></li>
                        <li><a href="addstudent.php">Add Student</a></li>
                        <li><a href="addfaculty.php">Add Faculty</a></li>
                        <li><a href="addadm.php">Add Admin</a></li>
                        <li><a href="admread.php">View Users</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

    <form action="" method="post">
    <div class="form__group field">
        <input type="text" class="form__field" name="studid" placeholder="Student ID" autocomplete="off" required>
        <label for="studid" class="form__label">Student ID</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="studname" placeholder="Student Name" autocomplete="off" required>
        <label for="studname" class="form__label">Student Name</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="email" placeholder="Student Email" autocomplete="off" required>
        <label for="email" class="form__label">Student email</label>
    </div>
    <div class="form__group field">
    
        <input type="password" class="form__field" name="password" placeholder="Password" autocomplete="off" required>
        <label for="password" class="form__label">Student password</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="age" placeholder="Student age" autocomplete="off" required>
        <label for="age" class="form__label">Student age</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="address" placeholder="Address" autocomplete="off" required>
        <label for="address" class="form__label">Student address</label>
    </div>
        <div class="rdbtn">
        <input type="radio" name="gender" value="Male">Male
        <input type="radio" name="gender" value="Female">Female 
        </div><br>
     <input type="submit" name="submit"  class="add" value="Add">


    </form>

</body>
</html>

<?php 

    if(isset($_POST['submit'])) {

        $studid = $_POST['studid'];
        $studname = $_POST['studname'];
        $studemail = $_POST['email'];
        $studpass = md5($_POST['password']);
        $studage = $_POST['age'];
        $studaddr = $_POST['address'];
        $studgender =$_POST['gender'];

        $qry = "INSERT INTO student values ('$studid', '$studname', '$studemail', '$studpass', '$studage', '$studaddr', '$studgender')";

        if(mysqli_query($conn, $qry)) {

            header('location:admread.php');

        }else {

            mysqli_error($conn);

        }
    }

?>

