<?php
    include 'config.php';
    session_start();
    include 'middlewares/student-guard.php';


?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial scale=1.0">
        <title>Homepage</title>
        <link rel="stylesheet" href="css/student.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,700;1,200;1,400&display=swap" rel="stylesheet">
    </head>
    <body>
        <section class="header">
            <nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="studhome.php">Home</a></li>
                        <li><a href="#">My Courses</a></li>
                        <li><a href="studentmnv.php">Mission and Vision</a></li>
                        <li><a href="studabout.php">About</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <div class="text-box">
                <h1>Welcome to TMCS LMS</h1>
                <p>"All the Knowledge right in your fingertips"<br>"There is nothing more pleasurable than wandering around the School."</p>
                <a href="https://www.facebook.com/TMCSOfficialpage" class="hero-btn">Visit Us To know more</a>
            </div>
        </section>
        <section class="course">
            <h1>Team Means</h1>
            <p>Shaping The Mind, Moulding The Heart</p>

            <div class="row">
                <div class="course-col">
                    <h3>T</h3>
                    <p>Team</p>
                </div>
                <div class="course-col">
                    <h3>E</h3>
                    <p>Education</p>
                </div>
                <div class="course-col">
                    <h3>A</h3>
                    <p>Accelerated</p>
                </div>
                <div class="course-col">
                    <h3>M</h3>
                    <p>Multi-Disciplinary</p>
                </div>
            </div>
            

        </section>
        <section class="campus">
            <h1>Our Campus</h1>
            <p>Train up a child in the way he should go<br>and when he is old, he will not depart from it.</p>

            <div class="row">
                <div class="campus-col">
                    <img src="img/picone.jpg" >
                    <div class="layer">
                        <h3>Faculty and Staff</h3>
                    </div>
                </div>
                <div class="campus-col">
                    <img src="img/lastone.jpg" >
                    <div class="layer">
                        <h3>A Home of Melody</h3>
                    </div>
                </div>
                <div class="campus-col">
                    <img src="img/court.jpg" >
                    <div class="layer">
                        <h3>Sports Event</h3>
                    </div>
                </div>
            </div>

        </section>

        <section class="cta">
            <h1>Enroll For Our Various Online Courses<br>Anywhere From Marilao, Bulacan</h1>
            <a href="https://www.facebook.com/TMCSOfficialpage" class="hero-btn">CONTACT US</a>
        </section>
    </body>
</html>