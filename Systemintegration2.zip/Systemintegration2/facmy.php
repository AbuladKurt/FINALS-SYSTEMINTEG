<?php

    include 'config.php';
    session_start();
    include 'middlewares/faculty-guard.php';

  
    $sql = "SELECT subj_name FROM subject WHERE faculty_id = " . $_SESSION['id'];
    $result = $conn->query($sql);

    if($result->num_rows > 0) {

        while($row = $result -> fetch_assoc()) {

            $value = $row['subj_name'];
            

        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/faculty.css">
    <title>My Course</title>
    <style>
        .card {
  width: 300px;
  height: 200px;
  background-color: #4158D0;
  background-image: linear-gradient(43deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%);
  border-radius: 8px;
  color: white;
  overflow: hidden;
  position: relative;
  transform-style: preserve-3d;
  perspective: 1000px;
  transition: all 0.5s cubic-bezier(0.23, 1, 0.320, 1);
  cursor: pointer;
}

.card-content {
  padding: 20px;
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
  color: white;
  align-items: center;
  justify-content: center;
  text-align: center;
  height: 100%;
}

.card-content .card-title {
  font-size: 24px;
  font-weight: 700;
  color: inherit;
  text-transform: uppercase;
}

.card-content .card-para {
  color: inherit;
  opacity: 0.8;
  font-size: 14px;
}

.card:hover {
  transform: rotateY(10deg) rotateX(10deg) scale(1.05);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.card:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.1));
  transition: transform 0.5s cubic-bezier(0.23, 1, 0.320, 1);
  z-index: 1;
}

.card:hover:before {
  transform: translateX(-100%);
}

.card:after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.1));
  transition: transform 0.5s cubic-bezier(0.23, 1, 0.320, 1);
  z-index: 1;
}

.card:hover:after {
  transform: translateX(100%);
}

.card {

    margin-top: 250px;
    left: 250px;

}







    </style>
</head>
<body>
<section class="header">
        <nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="facultyhome.php">Home</a></li>
                        <li><a href="facmy.php">My Courses</a></li>
                        <li><a href="facultymnv.php">Mission and Vision</a></li>
                        <li><a href="facultyabt.php">About</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
           
            <a href="#" >
            <div class="card">
  <div class="card-content">
    <p class="card-title"><?php echo $value; ?>
    </p><p class="card-para"></p>
  </div>
</div>
            </a>

            

            
  

            
</section>

    
</body>
</html>