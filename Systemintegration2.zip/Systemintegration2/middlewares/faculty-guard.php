<?php

    // CHECK IF IT'S LOGIN
    if(isset($_SESSION['id'])) {
       
        // $hanap="SELECT * from faculty where id = " . $_SESSION['id'];
        // $result=mysqli_query($conn,$hanap);
        // print_r($result->fetch_assoc());
        // // $bilang=mysqli_num_rows($result);
        // // echo $bilang;

        // if(!$result || mysqli_num_rows($result) == 0) {

        //     // header('location:facultylogin.php');
            

        // }

        if($_SESSION['type'] != 'faculty') {

            header('location:facultylogin.php');

        }



    }else {
// PAG DI NAKAPAG LOGIN
        header('location:facultylogin.php');

    }