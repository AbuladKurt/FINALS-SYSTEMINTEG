<?php 

if(isset($_SESSION['id'])) {


    if($_SESSION['type'] != 'admin') {

        header('location:admlogin.php');

    }

}else {

    header('location:admlogin.php');

}