<?php

if(isset($_SESSION['id'])) {

    if($_SESSION['type'] != 'student') {

        header('location:studlogin.php');

    }

}else {

    header('location:studlogin.php');

}