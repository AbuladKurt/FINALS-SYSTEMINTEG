<?php 

    include 'config.php';
    session_start();
    include 'middlewares/admin-guard.php';

    $id = $_GET['id'];

    $qry = "DELETE FROM admin WHERE admin_id = $id";

    if(mysqli_query($conn, $qry)) {

        header('location: admread.php');

    }else {

        echo mysqli_error($conn);

    }

?>