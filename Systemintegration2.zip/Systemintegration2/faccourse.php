<?php 

    include 'config.php';
    session_start();
    include 'middlewares/faculty-guard.php';

    $sql = "SELECT subj_name FROM subject WHERE faculty_id = " . $_SESSION['id'];
    $result = $conn->query($sql);

    if($result->num_rows > 0) {

        while($row = $result -> fetch_assoc()) {

            $value = $row['subj_name'];
            

        }

    }


?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial scale=1.0">
        <title>My Courses</title>
        <link rel="stylesheet" href="css/faculty.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,700;1,200;1,400&display=swap" rel="stylesheet">
    </head>
    <body>
    
        <section class="header">
        <nav>
                <div class="nameleft">
                        <h1 style="color: white;">FACULTY</h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="facultyhome.php">Home</a></li>
                        <li><a href="faccourse.php">My Courses</a></li>
                        <li><a href="facultymnv.php">Mission and Vision</a></li>
                        <li><a href="facultyabt.php">About</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <form action="" method="post">

                <select name="combo_box"> 
                        <?php

            $sql = "SELECT stud_id, stud_name FROM student";
            $result = $conn->query($sql);



            if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                        $id = $row["study_id"];
                        $value = $row['stud_name'];
                        echo '<option name = "" value = "' .$id . '">' . $value .'</option>';

                    }

            }

            ?>
            </select>
            <input type="submit" name="submit" value="Add Student">
                

</form>

        </section>

     

    </body>
</html>


