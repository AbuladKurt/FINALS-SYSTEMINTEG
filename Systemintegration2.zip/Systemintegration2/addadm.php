<?php 

    include 'config.php';
    session_start();
    include 'middlewares/admin-guard.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/design.css">
    <link rel="stylesheet" href="css/admin.css">
    <title>Add User</title>
</head>
<body>
<nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="admhome.php">Home</a></li>
                        <li><a href="admmycourse.php">My Courses</a></li>
                        <li><a href="addstudent.php">Add Student</a></li>
                        <li><a href="addfaculty.php">Add Faculty</a></li>
                        <li><a href="addadm.php">Add Admin</a></li>
                        <li><a href="admread.php">View Users</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

    <form action="" method="post">
    <div class="form__group field">
        <input type="text" class="form__field" name="admid" placeholder="Admin ID" autocomplete="off" required>
        <label for="admid" class="form__label">Admin ID</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="admname" placeholder="Admin Name" autocomplete="off" required>
        <label for="admname" class="form__label">Admin Name</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="email" placeholder="Admin Email" autocomplete="off" required>
        <label for="email" class="form__label">Admin email</label>
    </div>
    <div class="form__group field">
    
        <input type="password" class="form__field" name="password" placeholder="Password" autocomplete="off" required>
        <label for="password" class="form__label">Student password</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="age" placeholder="Admin age" autocomplete="off" required>
        <label for="age" class="form__label">Admin age</label>
    </div>
    <div class="form__group field">
    
        <input type="text" class="form__field" name="address" placeholder="Address" autocomplete="off" required>
        <label for="address" class="form__label">Admin address</label>
    </div>
        <div class="rdbtn">
        <input type="radio" name="gender" value="Male">Male
        <input type="radio" name="gender" value="Female">Female 
        </div><br>
     <input type="submit" name="submit"  class="add" value="Add">


    </form>

</body>
</html>

<?php 

    if(isset($_POST['submit'])) {

        $admid = $_POST['admid'];
        $admname = $_POST['admname'];
        $admemail = $_POST['email'];
        $admpass = md5($_POST['password']);
        $admage = $_POST['age'];
        $admaddr = $_POST['address'];
        $admgender =$_POST['gender'];

        $qry = "INSERT INTO admin values ('$admid', '$admname', '$admemail', '$admpass', '$admage', '$admaddr', '$admgender')";

        if(mysqli_query($conn, $qry)) {

            header('location:admread.php');

        }else {

            mysqli_error($conn);

        }
    }

?>

