<?php

    include 'config.php';
    session_start();

    if (isset($_POST['submit']))
    {
        // mysqli_connect(mysqlserver, user,Pass,dbname)
        // $conn=mysqli_connect("localhost", "root", "", "systeminteg") or die ("Error in connection");
        $_SESSION['email']=$_POST['email'];
        $email = $_POST['email'];
        $password=md5($_POST['password']);
        //Insertion of Records
        $hanap="SELECT * from admin where (email='$email' and password='$password')";
        $result=mysqli_query($conn,$hanap);
        $bilang=mysqli_num_rows($result);
        if ($bilang==1){

            $user = $result->fetch_assoc();
            $_SESSION["id"] = $user['admin_id'];
            $_SESSION["name"] = $user['admin_name'];
            $_SESSION["email"] = $user['email'];
            $_SESSION["type"] = "admin";
            header('location:admhome.php');

        }
            
        else{
            echo "<script>alert('Your Email or password is incorrect')</script>";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admlogin.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
    
    <form action="" method="post">
    <div class="icon">
            <i class="uil uil-envelope icon"></i>
    <input type="text" name="email" placeholder="Email" autocomplete="off" required>
    </div>
    <div class="icon">
                <i class="uil uil-lock icon"></i>
    <input type="password" name="password" placeholder="Password" autocomplete="off" required>
    </div>
    <input type="submit" name="submit" value="Login">

    </form>

    </div>

</body>
</html>