<?php 

    include 'config.php';
    include 'middlewares/admin-guard.php';

    $id = $_GET['id'];

    $qry = "DELETE FROM student WHERE stud_id = $id";

    if(mysqli_query($conn, $qry)) {

        header('location: admread.php');

    }else {

        echo mysqli_error($conn);

    }

?>