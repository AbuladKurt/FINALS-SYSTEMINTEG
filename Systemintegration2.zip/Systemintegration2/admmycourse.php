<?php

    include 'config.php';
    session_start();
    include 'middlewares/admin-guard.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/design.css">
    <link rel="stylesheet" href="css/admin.css">
    <title>Add Subject</title>
</head>
<body>
    
<nav>
                <div class="nameleft">
                        <h1 style="color: white;"><?= $_SESSION["name"]; ?></h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="admhome.php">Home</a></li>
                        <li><a href="admmycourse.php">My Courses</a></li>
                        <li><a href="addstudent.php">Add Student</a></li>
                        <li><a href="addfaculty.php">Add Faculty</a></li>
                        <li><a href="addadm.php">Add Admin</a></li>
                        <li><a href="admread.php">View Users</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

        
    <form action="" method="post">
        <div class="form__group field">
        <input type="text" class="form__field" name="subjid" placeholder="Subject ID" autocomplete="off" required>
            <label for="subjid" class="form__label">Subject ID</label>
        </div><br>
            
        <div class="form__group field">
        <input type="text" class="form__field"  name="subjname" placeholder="Subject Name" autocomplete="off" required>
            <label for="subjname" class="form__label">Subject Name</label> 
        </div><br>
            
            
            <label for="combo_box">Faculty</label> <br><br>
            <select name="combo_box"> 
                    <?php

        $sql = "SELECT faculty_id, faculty_name FROM faculty";
        $result = $conn->query($sql);



        if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

                    $id = $row["faculty_id"];
                    $value = $row['faculty_name'];
                    echo '<option value = "' .$id . '">' . $value .'</option>';
        
                }

        }

        ?>
            </select> <br><br>
        
            <div class="form__group field">
            <input type="text" name="unit" class="form__field" placeholder="Unit" autocomplete="off" required>
            <label for="unit" class="form__label">Units</label>
            </div>
            

            
            <input type="submit" name="submit" class="add" value="Add subject">

    </form>



</body>
</html>

<?php

    if (isset($_POST['submit'])) {

        $subjid = $_POST['subjid'];
        $subjname = $_POST['subjname'];
        $studid = $_POST['combo_box'];
        $unit = $_POST['unit'];

        $qry = "INSERT INTO subject values ('$subjid', '$subjname', '$studid', '$unit')";

        if(mysqli_query($conn, $qry)) {

            header('location:admread.php');

        } else {

            mysqli_error($conn);

        }

    }

?>