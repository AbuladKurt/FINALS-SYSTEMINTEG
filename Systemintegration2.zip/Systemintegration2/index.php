<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Index</title>
    <style>
         * {

padding: 0;
margin: 0;
box-sizing: border-box;

}
         .header {


min-height: 100vh;
width: 100%;
background-image: linear-gradient(rgba(4,9,30,0.7),rgba(4,9,30,0.7)),url(img/bgc.jpg);
background-position: center;
background-size: cover;

}

.header {

    display: flex;
    align-items: center;
    text-align: center;

}

.midol {

        display: flex;
        align-items: center;
        text-align: center;
        margin-left: 23%;

}

.scene {

    margin-left: 100px;

}
    </style>
</head>
<body>
    <div class="header">
        <div class="midol">
        <a href="studlogin.php">
        <div class="scene">
            <div class="cube">
            <span class="side top">Login</span>
            <span class="side front">Student</span>
            </div>
            </div>
        </a>
   
        <a href="facultylogin.php">
        <div class="scene">
            <div class="cube">
            <span class="side top">Login</span>
            <span class="side front">Faculty</span>
            </div>
            </div>
        </a>
            
        <a href="admlogin.php">
        <div class="scene">
            <div class="cube">
            <span class="side top">Login</span>
            <span class="side front">Admin</span>
            </div>
            </div>
        </a>
        </div>
    
    </div>
    
       
   


</body>
</html>