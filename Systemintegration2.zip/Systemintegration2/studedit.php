<?php

    include 'config.php';
    session_start();
    include 'middlewares/admin-guard.php';

    if(!$conn) {

        die('Error in db' . mysqli_error($conn));

    }else {

        $id = $_GET['id'];
        $qry = "SELECT * FROM student WHERE stud_id = $id";
        $run = $conn->query($qry);
        if ($run->num_rows > 0) {

            while ($row = $run -> fetch_assoc()) {

                $studid = $row['stud_id'];
                $studname = $row['stud_name'];
                $email = $row['email'];
                $password = $row['password'];
                $age = $row['age'];
                $address = $row['addr'];
                $gender = $row['gender'];

            }

        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/design.css">
    <link rel="stylesheet" href="css/admin.css">
    <title>Update User</title>
</head>
<body>
<nav>
                <div class="nameleft">
                        <h1 style="color: white;">ADMIN</h1>
                </div>
               
                <div class="nav-links">
                    <ul>
                        <li><a href="admhome.php">Home</a></li>
                        <li><a href="">My Courses</a></li>
                        <li><a href="addstudent.php">Add Student</a></li>
                        <li><a href="addfaculty.php">Add Faculty</a></li>
                        <li><a href="addadm.php">Add Admin</a></li>
                        <li><a href="admread.php">View Users</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <form action="" method="post">
    <div class="form__group field">
        <input type="text" class="form__field" name="stud_id" value="<?php echo $studid; ?>" placeholder="Student ID" required>
        <label for="stud_id" class="form__label">Student ID </label>
    </div><br>

    <div class="form__group field">
        <input type="text" class="form__field" name="stud_name" value="<?php echo $studname; ?>" placeholder="Student Name" required>
        <label for="stud_name" class="form__label">Student Name </label>
    </div><br>

    <div class="form__group field">
        <input type="text" class="form__field" name="email" value="<?php echo $email; ?>" placeholder="E-mail" required>
        <label for="email" class="form__label">E-mail </label>
    </div><br>

    <div class="form__group field">
        <input type="password" class="form__field" name="password" value="" placeholder="Password" required>
        <label for="password" class="form__label">Password</label>
    </div><br>

    <div class="form__group field">
        <input type="text" class="form__field" name="age" value="<?php echo $age; ?>" placeholder="Age" required>
        <label for="age" class="form__label">Age </label>
    </div><br>

    <div class="form__group field">
        <input type="text" class="form__field" name="addr" value="<?php echo $address; ?>" placeholder="Address" required>
        <label for="addr" class="form__label">Address</label>
    </div><br>
    </div>
        <div class="rdbtn">
        <input type="radio" name="gender" value="Male">Male
        <input type="radio" name="gender" value="Female">Female 
        </div><br>
        <input type="submit" name="update"  class="update" value="Update">
   
</body>
</html>

<?php

    if(isset($_POST['update'])) {

        $id = $_GET['id'];
        $studid = $_POST['stud_id'];
        $studname = $_POST['stud_name'];
        $email = $_POST['email'];
        $password= md5($_POST['password']);
        $age = $_POST['age'];
        $address = $_POST['addr'];
        $gender = $_POST['gender'];

        $qry = "UPDATE student SET stud_id = '$studid', stud_name = '$studname', email = '$email', password = '$password', age = '$age', addr = '$address', gender = '$gender' WHERE stud_id = $id";

        if($conn->query($qry) == TRUE) {

            header('location: admread.php');

        } else {

            echo mysqli_error($conn);

        }

    }

?>